﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      

        private void btnSoma_Click(object sender, EventArgs e)
        {
            int varNum1 = int.Parse(txtNum1.Text);
            float varNum2 = int.Parse(txtNum2.Text);
            float resultado;
            resultado = varNum1 + varNum2;
            MessageBox.Show("Soma: " + resultado);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            int varNum1 = int.Parse(txtNum1.Text);
            float varNum2 = int.Parse(txtNum2.Text);
            float resultado;
            resultado = varNum1 - varNum2;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            int varNum1 = int.Parse(txtNum1.Text);
            float varNum2 = int.Parse(txtNum2.Text);
            float resultado;
            resultado = varNum1 * varNum2;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            int varNum1 = int.Parse(txtNum1.Text);
            float varNum2 = int.Parse(txtNum2.Text);
            float resultado;
            resultado = varNum1 / varNum2;
            MessageBox.Show("Divisão: " + resultado);
        }
    }
}
