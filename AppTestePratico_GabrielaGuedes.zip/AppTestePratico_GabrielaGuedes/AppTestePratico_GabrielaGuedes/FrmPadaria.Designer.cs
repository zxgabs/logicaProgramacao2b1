﻿namespace AppTestePratico_GabrielaGuedes
{
    partial class FrmPadaria
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPadaria));
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.lblQtdBroas = new System.Windows.Forms.Label();
            this.txtQtdPaes = new System.Windows.Forms.TextBox();
            this.txtQtdBroas = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblValor = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTitulo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(177)))), ((int)(((byte)(255)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(-7, -5);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(679, 61);
            this.pnlTitulo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(19, 24);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(176, 24);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Questão padaria";
            this.lblTitulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.Location = new System.Drawing.Point(12, 74);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(195, 22);
            this.lblQtdPaes.TabIndex = 1;
            this.lblQtdPaes.Text = "Quantidade de pães";
            // 
            // lblQtdBroas
            // 
            this.lblQtdBroas.AutoSize = true;
            this.lblQtdBroas.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroas.Location = new System.Drawing.Point(12, 162);
            this.lblQtdBroas.Name = "lblQtdBroas";
            this.lblQtdBroas.Size = new System.Drawing.Size(206, 22);
            this.lblQtdBroas.TabIndex = 2;
            this.lblQtdBroas.Text = "Quantidade de Broas";
            // 
            // txtQtdPaes
            // 
            this.txtQtdPaes.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdPaes.Location = new System.Drawing.Point(16, 111);
            this.txtQtdPaes.Name = "txtQtdPaes";
            this.txtQtdPaes.Size = new System.Drawing.Size(100, 26);
            this.txtQtdPaes.TabIndex = 3;
            // 
            // txtQtdBroas
            // 
            this.txtQtdBroas.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdBroas.Location = new System.Drawing.Point(16, 206);
            this.txtQtdBroas.Name = "txtQtdBroas";
            this.txtQtdBroas.Size = new System.Drawing.Size(100, 26);
            this.txtQtdBroas.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(228)))), ((int)(((byte)(255)))));
            this.btnCalcular.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(16, 262);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 30);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(177)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.lblResultado);
            this.panel1.Controls.Add(this.lblValor);
            this.panel1.Location = new System.Drawing.Point(-7, 323);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(680, 88);
            this.panel1.TabIndex = 6;
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(19, 28);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(171, 29);
            this.lblValor.TabIndex = 0;
            this.lblValor.Text = "Valor a pagar:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(196, 28);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(43, 29);
            this.lblResultado.TabIndex = 1;
            this.lblResultado.Text = "R$";
            this.lblResultado.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(207)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(346, 408);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtQtdBroas);
            this.Controls.Add(this.txtQtdPaes);
            this.Controls.Add(this.lblQtdBroas);
            this.Controls.Add(this.lblQtdPaes);
            this.Controls.Add(this.pnlTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Padaria";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.Label lblQtdBroas;
        private System.Windows.Forms.TextBox txtQtdPaes;
        private System.Windows.Forms.TextBox txtQtdBroas;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label lblValor;
    }
}

