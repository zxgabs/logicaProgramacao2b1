﻿using System;
using System.Windows.Forms;

namespace AppTestePratico_GabrielaGuedes
{
    public partial class FrmPadaria : Form
    {
        public FrmPadaria()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores da tela
            int qtdPaes = int.Parse(txtQtdPaes.Text);
            int qtdBroas = int.Parse(txtQtdBroas.Text);
            float total;

            //Fazer o cálculo
            total = qtdBroas * 1.50f + qtdPaes * 0.12f;

            //Mostrar o resultado em uma label
            lblResultado.Text = "R$" + total;
        }
    }
}
